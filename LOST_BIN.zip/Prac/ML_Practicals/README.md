# ML_Practicals

This repo contains practicals files of Machine Learning that are part of curriculum of Semester 6
