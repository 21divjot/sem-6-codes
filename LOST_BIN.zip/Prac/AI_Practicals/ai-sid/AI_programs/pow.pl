power(N,0,A):-
A is 1.

power(N,P,A):-
A is N^P.
