can-cook(priya).
can-cook(alisha).
can-cook(anisha).

like(priya,alisha):-can-cook(alisha).
like(priya,anisha):-can-cook(anisha).
