# AI_Praticals

This repo containes all AI practicals that are part of curriculum of Semester 6
