temp(X,Y):- X=Y,write("Equal").
temp(X,Y):- X\=Y,write("Not-Equal").