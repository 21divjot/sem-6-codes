
max(X,Y,Z):- X>Y -> Z is X;Z is Y.