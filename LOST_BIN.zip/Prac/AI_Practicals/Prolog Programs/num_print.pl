prnt(X, Y) :- Y =\= X -> write(Y), write(', '), Z is Y + 1, prnt(X, Z) ; write(Y), nl, !.

print :- write('X - '),
	read(X),
	prnt(X, 1).

