max(X, Y, Z) :- Y > X -> Z is Y; Z is X.
min(X, Y, Z) :- Y < X -> Z is Y; Z is X.

max_min :- write('\e[H\e[2J'),
	write('Number 1 - '),
	read(X),
	write('Number 2 - '),
	read(Y),
	write('1 - Max, 2 - Min'), nl,
	read(M),
	(number(X), number(Y)) -> 
		mx_mn(X, Y, Z, M),
		write(Z), nl,
		write('Press y to continue - '),
		read(N),
		check(N)
	; write('X and Y should be numbers'), nl, write('Press y to continue - '),
		read(N),
		check(N).
	
mx_mn(X, Y, Z, 1) :- write('Max - '), max(X, Y, Z).

mx_mn(X, Y, Z, 2) :- write('Min - '), min(X, Y, Z).

mx_mn(_, _, _, _) :- write('Incorrect option.'), !.
	
check(y) :- max_min.

check(_) :- !.

