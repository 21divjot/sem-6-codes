fibn1(0, Y) :- Y is 0, !.
fibn1(1, Y) :- Y is 1, !.
fibn1(X, Y) :- M is X - 1, Z is X - 2, fibn1(M, A), fibn1(Z, B), Y is A + B, !.
fibn(X, Y) :- X < 0 -> write('Number is negative'), nl, Y is -1, ! ; fibn1(X, Y).

fib :- write('\e[H\e[2J'),
	write('Number - '),
	read(X),
	number(X) ->
	fibn(X, Y),
	write('Fibonacci value at '), write(X), write(' = '), write(Y), nl,
	write('Press y to continue - '),
	read(M),
	check(M) ; write('Incorrect value'), !.
	
check(y) :- fib.

check(_) :- !.

