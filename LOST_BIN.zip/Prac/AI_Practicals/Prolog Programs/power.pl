pow1(X, 0, Z) :- Z is 1, !.
pow1(X, 1, Z) :- Z is X, !.
pow1(X, Y, Z) :- M is Y - 1, pow1(X, M, A), Z is X * A.
pow(X, Y, Z) :- Y < 0 -> write("Power is negative"), nl, Z is -1, ! ; pow1(X, Y, Z).

power :- write('Number - '),
	read(X),
	write('Power - '),
	read(Y),
	pow(X, Y, Z),
	write(X), write('^'), write(Y), write(' = '), write(Z), nl,
	write('Press y to continue - '),
	read(M),
	check(M).
	
check(y) :- power.

check(M) :- !.

