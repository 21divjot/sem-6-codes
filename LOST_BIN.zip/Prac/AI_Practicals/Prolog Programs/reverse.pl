%concat([], L2, L2).
%concat([ H|T ], L2, [ H|R ]) :- concat(T, L2, R).

rev([], _, R, R).
rev([ H|T ], M, R, X) :- M = 0 -> rev(T, 1, [ H ], X) ; rev(T, 1, [ H|R ], X).

prog :- write('\e[H\e[2J'),
	write('List - '),
	read(L),
	rev(L, 0, R, X).

pal(L, R) :- rev(L, 0, R, X), L = X -> write('Palindrome') ; write('Not a palindrome').

