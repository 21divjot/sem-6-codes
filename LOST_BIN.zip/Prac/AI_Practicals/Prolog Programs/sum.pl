sum :- write('Enter 1st number - '),
	read(X),
	write('Enter 2nd number - '),
	read(Y),
	calculate(X, Y).
	
calculate(X, Y) :- Z is X + Y,
	write(X), write('+'), write(Y), write(' = '), write(Z), nl,
	write('Press y to continue - '),
	read(M),
	check(M).

check(y) :- sum.

check(M) :- !.

