memb(_, []) :- false, !.
memb(E, [ H|T ]) :- E = H -> true, ! ; memb(E, T).

memb1(E, X) :- memb(E, X) -> write('Number found'); write('Number not found'), !.

prog :- write('\e[H\e[2J'),
	write('Description - '), nl, write('Check whether an element is present in the list'), nl, nl,
	write('Value - '),
	read(E),
	write('List values  - '),
	read(X),
	memb1(E, X), nl,
	write('Press y to continue'),
	read(O),
	check(O) -> write('Press y to continue with same list'), read(S), checkS(S, X) ; !.

prog2(X) :- write('\e[H\e[2J'),
	write('Description - '), nl, write('Check whether an element is present in the list'), nl, nl,
	write(X), nl,
	write('Value - '),
	read(E),
	memb1(E, X), nl,
	write('Press y to continue'),
	read(O),
	check(O) -> write('Press y to continue with same list'), read(S), checkS(S, X) ; !.

check(y) :- true.
check(_) :- false.

checkS(y, X) :- prog2(X).
checkS(_, _) :- prog.

