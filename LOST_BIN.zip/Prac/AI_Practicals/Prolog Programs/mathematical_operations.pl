sum(X, Y, Z) :- write(X), write('+'), write(Y), write(' = '), Z is X + Y.
difference(X, Y, Z) :-  write(X), write('-'), write(Y), write(' = '), Z is X - Y.
multiply(X, Y, Z) :- write(X), write('*'), write(Y), write(' = '), Z is X * Y.
divide(X, Y, Z) :- write(X), write('/'), write(Y), write(' = '), Z is X / Y.

math_op :- write('\e[H\e[2J'),
	write('Enter 1st no. - '),
	read(X),
	write('Enter 2nd no. - '),
	read(Y),
	(number(X), number(Y)) ->
		write('Press a - addition, s - subtraction, m - multiplication, d - divide - '),
		read(O),
		call_op(X, Y, Z, O),
		write(Z), nl,
		write('Press y to continue - '),
		read(M),
		check(M)
	; write('X and Y should be numbers'), !.

call_op(X, Y, Z, a) :- sum(X, Y, Z).
call_op(X, Y, Z, s) :- difference(X, Y, Z).
call_op(X, Y, Z, m) :- multiply(X, Y, Z).
call_op(X, Y, Z, d) :- divide(X, Y, Z).
call_op(_, _, _, _) :- write('Incorrect option.'), !.

check(y) :- math_op.

check(_) :- !.

