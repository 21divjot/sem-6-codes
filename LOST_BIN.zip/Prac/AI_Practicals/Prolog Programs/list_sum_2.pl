list_sum([], R) :- write(R).
list_sum([ _|[] ], R) :- write('Called'), list_sum([], R).
list_sum([ H1, H2|T ], R) :- X is H1 + H2, list_sum([ X|T ], X).

