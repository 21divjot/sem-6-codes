evenLength([], R, R).
evenLength([ _|[] ], R, R) :- Z is R+1, evenLength([], Z, R).
evenLength([ _|T ], X, R) :- Z is X + 1, evenLength(T, Z, R).

