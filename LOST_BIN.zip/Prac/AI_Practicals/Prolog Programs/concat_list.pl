concat([], L2, L2).
%concat([ H|T ], [ A|R ], D) :- T = [] -> write(H), write(' '), write(A), concat([''|T], R) ;
	%write(H), write(' '), concat(T, [ A|R ]).
concat([ H|T ], L2, [ H|R ]) :- concat(T, L2, R).

