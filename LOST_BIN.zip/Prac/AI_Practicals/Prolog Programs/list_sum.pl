list_sum([], R, R).
list_sum([ H|[] ], M, R) :- X is M + H, list_sum([], X, R).
list_sum([ H|T ], M, R) :- X is M + H, list_sum(T, X, R).

prog :- write('\e[H\e[2J'),
	write('List - '),
	read(L),
	list_sum(L, 0, R),
	write(R), nl,
	write('Pres y to continue'),
	read(O),
	check(O).

check(y) :- prog.
check(_) :- !.

