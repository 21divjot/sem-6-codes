male(jawaharlal).
male(rahul).
male(feroze).
male(rajiv).
male(sanjay).
male(varun).
female(kamala).
female(indira).
female(sonia).
female(priyanka).
female(menaka).
parent(sonia, rahul).
parent(rajiv, rahul).
parent(sonia, priyanka).
parent(rajiv, priyanka).
parent(menaka, varun).
parent(sanjay, varun).
parent(feroze, rajiv).
parent(feroze, sanjay).
parent(indira, rajiv).
parent(indira, sanjay).
parent(jawaharlal, indira).
parent(kamala, indira).
father(X, Y) :- male(X), parent(X, Y).
mother(X, Y) :- female(X), parent(X, Y).
grandfather(X, Y) :- father(X, Z), father(Z, Y), !.
mgrandfather(X, Y) :- father(X, Z), mother(Z, Y), !.
grandmother(X, Y) :- mother(X, Z), father(Z, Y), !.
mgrandmother(X, Y) :- mother(X, Z), mother(Z, Y), !.
brother(X, Y) :- male(X), parent(Z, X), parent(Z, Y).
sister(X, Y) :- female(X), parent(Z, X), parent(Z, Y).
wife(X, Y) :- female(X), male(Y), mother(X, Z), father(Y, Z), !.
husband(X, Y) :- male(X), female(Y), father(X, Z), mother(Y, Z), !.
uncle(X, Y) :- male(X), parent(Z, Y), brother(X, Z).
aunt(X, Y) :- female(X), parent(Z, Y), sister(X, Z).

ancestor(X, Y) :- parent(X, Y).
ancestor(X, Y) :- parent(X, Z), ancestor(Z, Y).

