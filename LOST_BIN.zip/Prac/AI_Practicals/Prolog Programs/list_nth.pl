list_nth([], _, _, _) :- write('Index out of range').
list_nth([ H|T ], N, X, R) :- N = X -> write(H), ! ; M is X + 1, list_nth(T, N, M, R).

