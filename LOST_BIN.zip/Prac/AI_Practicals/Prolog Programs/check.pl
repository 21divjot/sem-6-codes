b(1).
a(1).
a(4).
b(3).
c(2).
d(1).
d(2).
e(X) :- a(X), !, false.
e(X) :- c(X), d(X).
e(X) :- b(X).

