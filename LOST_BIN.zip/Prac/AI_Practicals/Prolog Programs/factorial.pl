factorial1(0, 1) :- !.
factorial1(X, Y) :- Z is X - 1, factorial(Z, A), Y is X * A, !.
factorial(X, Y) :- X < 0 -> write("Number is negative."), nl, Y is -1, ! ; factorial1(X, Y).

factorialn :- write('Number - '),
	read(X),
	factorial(X, Y),
	write(X), write('! = '), write(Y), nl,
	write('Press y to continue - '),
	read(M),
	check(M).

check_neg(-1) :- !.

check(y) :- factorialn.

check(M) :- !.

