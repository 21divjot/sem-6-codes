gcdX(X, _, Z, _) :- X < 1, Z is 1, write('GCD -'), write(Z), !.

gcdX(1, _, Z, _) :- Z is 1, write('GCD -'), write(Z), !.

gcdX(X, Y, Z, B) :- A is Y mod X, C is B mod X,
	A =:= 0, C =:= 0 -> 
			Z is X, write('GCD ='), write(Z), ! ; 
		gcdX(X - 1, Y, Z, B).
		
gcd1(X, Y, Z) :- (X < 0 ; Y < 0) -> write('Enter positive numbers'), ! ; X < Y -> gcdX(X, Y, Z, X) ; gcdX(Y, X, Z, Y).

gcd :- write('X - '), read(X), write('Y - '), read(Y),
	(number(X), number(Y)) ->	
	gcd1(X, Y, _), nl,
	write('Press y to continue - '), read(O), check(O) ; write('X and Y should be numbers'), !.
	
check(y) :- gcd.

check(_) :- !.

