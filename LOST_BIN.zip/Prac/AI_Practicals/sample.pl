language(java).
language(R).
language(python).