dog(rover).
dog(felix).
dog(berry).
animal(A):-dog(A).